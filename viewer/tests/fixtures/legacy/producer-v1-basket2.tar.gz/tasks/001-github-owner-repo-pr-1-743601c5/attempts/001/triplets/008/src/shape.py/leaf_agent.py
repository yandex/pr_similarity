leaf = 3
