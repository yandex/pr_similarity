shape = 1
