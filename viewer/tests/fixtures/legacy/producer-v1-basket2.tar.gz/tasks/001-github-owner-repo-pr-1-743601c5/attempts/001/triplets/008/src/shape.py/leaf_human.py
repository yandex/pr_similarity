leaf = 2
